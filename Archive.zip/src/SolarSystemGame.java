import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

import java.lang.Math;
import java.net.URL;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;


public class SolarSystemGame extends JFrame {

    private Font airacobra1, airacobra2, airacobra3, airacobra5;
    private boolean restartButton = false;
    private Image merc;
    private Image mars;
    private Image venus;
    private Image earth;
    private Image nep;
    private Image uran;
    private Image sat;
    private Image jup;
    private Color darkGray = new Color(37, 42, 54);
    private Color gray1 = new Color(46,52,57);
    private Color gray2 = new Color(54,62,68);
    private Color blueGray = new Color(158, 166, 180);
    private ArrayList<Planet> planets = new ArrayList<>();
    private ArrayList<Planet> circles = new ArrayList<>();
    private ArrayList<Integer> scores = new ArrayList<>();
    int y;
    int ind;
    Random rng = new Random();
    private Clip collisionSound;
    private static Clip music;
    private int currentScore = 0;
    File song = new File("Retro-style-synth-music-loop.wav");
 
 
    public SolarSystemGame() {
        setTitle("Solar System Game");
        setSize(800, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(new Highscore(), BorderLayout.WEST);
        add(new Gameplay(), BorderLayout.CENTER);
        add(new Title(), BorderLayout.NORTH);

        loadPlanets();
        
        pack(); 
        setLocationRelativeTo(null); 
        setVisible(true);
        
        
        try {
			AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(song);
			music = AudioSystem.getClip();
			music.open(audioInputStream);
		} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
			e.printStackTrace();
		}
        
        
      //  sound = ".//res//bloop_x.wav";
    }
   
    private static void playMusic() {
	    music.start();
	    music.loop(music.LOOP_CONTINUOUSLY);
	}
    
    

    private void loadPlanets() {
        planets.add(new Planet("Mercury", 50, merc));
        planets.add(new Planet("Mars", 60, mars));
        planets.add(new Planet("Venus", 80, venus));
        planets.add(new Planet("Earth", 110, earth));
        planets.add(new Planet("Neptune", 150, nep));
        planets.add(new Planet("Uranus", 200, uran));
        planets.add(new Planet("Saturn", 270, sat));
        planets.add(new Planet("Jupiter", 270, jup));
        
    }

   
    
    public static void main(String[] args) {
 
    	new SolarSystemGame();
    	playMusic();
      
    }

    
    
    public class Highscore extends JPanel {
    	
    	
        public Highscore() {
        	
        	try {
                Font font = Font.createFont(Font.TRUETYPE_FONT, new File("Airacobra.ttf"));
                airacobra2 = font.deriveFont(17f);
                airacobra3 = font.deriveFont(35f);
                airacobra5 = font.deriveFont(50f);
                GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
                ge.registerFont(font);
            } catch (IOException | FontFormatException e) {
                e.printStackTrace();
            }
        	 setBackground(darkGray);
             setPreferredSize(new Dimension(250, 800));
             JButton restart = new JButton("Restart");
             restart.setFont(airacobra3);
             add(restart);
             setLayout(new BorderLayout());
             restart.setFont(airacobra3);
             restart.setBounds(50, 50, 150, 75);
             restart.addActionListener(e -> {
            	((Gameplay) getParent().getComponent(1)).resetGame();
            	 scores.add(currentScore);
            	 Collections.sort(scores);
            	 Collections.reverse(scores);
            	 currentScore = 0;
             });
        }


        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(gray1);            
            g.fillRect(0, 205, 350, 575);
            g.setColor(gray2);
            g.fillRect(0, 410, 350, 575);
            g.setColor(blueGray);
            g.fillRect(50, 160, 150, 75);
            g.setColor(Color.black);
            g.setFont(airacobra2);
            g.drawString("CURRENT SCORE", 55, 178);
            
          //  g.drawRect(50, 300, 150, 225);
            g.setColor(blueGray);
            g.fillRect(50, 285, 150, 75);
            g.fillRect(50, 370, 150, 75);
            g.fillRect(50, 455, 150, 75);
            g.setColor(Color.black);
            g.drawString("TOP SCORE", 55, 303);
            g.drawString("2ND BEST", 55, 388);
            g.drawString("3RD BEST", 55, 473);
            g.setFont(airacobra3);
            //g.drawLine(50, 375, 200, 375);
           // g.drawLine(50, 450, 200, 450);
            g.drawString(Integer.toString(currentScore), 100, 215);
            repaint();
                
             if(scores.size() >= 3) {
            	g.drawString("" + scores.get(0), 100, 350);
            	g.drawString("" + scores.get(1), 100, 435);
            	g.drawString("" + + scores.get(2), 100, 520);
            }
         
            else if(scores.size() == 2) {
            	g.drawString("" + scores.get(0), 100, 350);
            	g.drawString("" + + scores.get(1), 100, 435);
            	g.drawString("0", 100, 520);
            }
            
            else if(scores.size() == 1) {
            	g.drawString("" + scores.get(0), 100, 350);
            	g.drawString("0", 100, 435);
            	g.drawString("0", 100, 520);
            }
           
            else if(scores.size() == 0) {
            	g.drawString("0", 100, 350);
            	g.drawString("0", 100, 435);
            	g.drawString("0", 100, 520);
            }
        }
    }
    
    public class Gameplay extends JPanel implements MouseListener{
    	
        Timer timer;
        int velocity;
        int x;
        int y = 15;
        int ind;
        Planet beforeLast;
        Planet selectedImage;               
        File song = new File("Retro-style-synth-music-loop.wav");
        File bloop = new File("bloop_x.wav");
        File outro = new File("outro-song_oqu8zAg.wav");
        File mar = new File("discord-notification-_1_.wav");
        File mercu = new File("anime-wow-sound-effect_1.wav");
        File ven = new File("yippee.wav");
        File eart = new File("bloop_x.wav");
        File nept = new File("uranus.wav");
        File ura = new File("vine-boom(1).wav\"");
        File satu = new File("saturn (1).wav");
        File[] sounds = {bloop, outro, mar, mercu, ven, eart, nept, ura, satu};
         
        public void resetGame() {
        	circles.clear();
        	restartButton = false;
        	repaint();
        }

        public Gameplay() {
            setFocusable(true);
            setBackground(darkGray);

            addMouseListener(this);
            setFocusable(true);     
            
            //playSong();

            merc = new ImageIcon("mercury1.PNG").getImage();
            mars = new ImageIcon("mars1.PNG").getImage();
            venus = new ImageIcon("venus1.PNG").getImage();
            earth = new ImageIcon("earth1.PNG").getImage();
            nep = new ImageIcon("neptune1.PNG").getImage();
            uran = new ImageIcon("uranus1.PNG").getImage();
            sat = new ImageIcon("saturn1.PNG").getImage();
            jup = new ImageIcon("jupiter1.PNG").getImage();
            
      
            
  
        }
        
        public void setFile(int i) {
       	 try {
   				AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(sounds[i]);
   				collisionSound = AudioSystem.getClip();
   				collisionSound.open(audioInputStream);
   			} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
   				e.printStackTrace();
   			}
       	 
       	 
        }
        
        private void play(int i) {
        	setFile(i);
    	    collisionSound.start();
    	}
        

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (restartButton) {
            	g.clearRect(75, 75, 400, 550);
            	g.fillRect(75, 75, 400, 550);
                System.out.println("Restarting...");
            }
            g.setColor(gray1);
            g.fillRect(0, 205, 700, 500);
            g.setColor(gray2);
            g.fillRect(0, 410, 700, 500);
            g.drawRect(75, 75, 400, 550);
            g.setColor(new Color(86, 61, 130));
            g.fillRect(75, 75, 400, 550);
            
            for (int i = 0; i < circles.size() - 2; i++) {
            	Planet planeti = circles.get(i);
            	if(planeti.y <= 75) {
          		 g.setColor(Color.black);
                 g.setFont(airacobra5);
          		 g.drawString("YOU LOSE! TRY AGAIN", 0, 200);
          		 play(1);
            	}
            }


            for (Planet planet : circles) {
                g.drawImage(planet.image, planet.x, planet.y, planet.size, planet.size, null);
            }

        }      
        
       private void checkforCollision() {
        	
        	
      	Graphics g = getGraphics();
            for (int i = 0; i < circles.size() - 1; i++) {
                Planet planet1 = circles.get(i);
                for (int j = i + 1; j < circles.size(); j++) {
                    Planet planet2 = circles.get(j);
                    if (planet1.size == planet2.size && planet1.image == merc && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(mars, 60, planet1.x, planet1.y - 10);
                        circles.remove(planet2);
                        circles.set(i, newPlanet);
                        currentScore += 5;
                        play(2);
                       
                    } 
                    if (planet1.size == planet2.size && planet1.image == mars && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(venus, 80, planet1.x, planet1.y - 20);
                        circles.remove(planet2);
                        circles.set(i, newPlanet);
                        currentScore += 10;
                        play(3);
                        
                    }
                    if (planet1.size == planet2.size && planet1.image == venus && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(earth, 110, planet1.x, planet1.y - 30);
                        circles.remove(planet2);
                        circles.set(i, newPlanet);
                        currentScore += 20;
                        play(4);
                    }
                    if (planet1.size == planet2.size && planet1.image == earth && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(nep, 150, planet1.x, planet1.y - 40);
                        circles.remove(planet2);
                    	circles.set(i, newPlanet);
                        currentScore += 35;
                        play(5);
                    }
                    if (planet1.size == planet2.size && planet1.image == nep && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(uran, 200, planet1.x, planet1.y - 50);
                        circles.remove(planet2);
                    	circles.set(i, newPlanet);
                        currentScore += 60;
                        play(6);
                    } 
                    if (planet1.size == planet2.size && planet1.image == uran && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(sat, 270, planet1.x, planet1.y - 70);
                        circles.remove(planet2);
                    	circles.set(i, newPlanet);
                        currentScore += 150;
                        play(7);
                    }  
                    if (planet1.size == planet2.size && planet1.image == sat && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(jup, 270, planet1.x, planet1.y);
                        circles.remove(planet2);
                    	circles.set(i, newPlanet);
                        currentScore += 500;
                        g.drawString("YOU WIN! PLAY AGAIN?", 0, 200);
                        play(8);
                    } 
                }
            }
            
            for (int i = circles.size() - 1; i ==0; i--) {
                Planet planet1 = circles.get(i);
                for (int j = 0; j < circles.size(); j++) {
                    Planet planet2 = circles.get(j);
                    if (planet1.size == planet2.size && planet1.image == merc && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(mars, 60, planet1.x, planet1.y - 10);
                        circles.remove(planet2);
                        circles.set(i, newPlanet);
                        currentScore += 5;
                        play(2);
                       
                    } 
                    if (planet1.size == planet2.size && planet1.image == mars && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(venus, 80, planet1.x, planet1.y - 20);
                        circles.remove(planet2);
                        circles.set(i, newPlanet);
                        currentScore += 10;
                        play(3);
                        
                    }
                    if (planet1.size == planet2.size && planet1.image == venus && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(earth, 110, planet1.x, planet1.y - 30);
                        circles.remove(planet2);
                        circles.set(i, newPlanet);
                        currentScore += 20;
                        play(4);
                    }
                    if (planet1.size == planet2.size && planet1.image == earth && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(nep, 150, planet1.x, planet1.y - 40);
                        circles.remove(planet2);
                    	circles.set(i, newPlanet);
                        currentScore += 35;
                        play(5);
                    }
                    if (planet1.size == planet2.size && planet1.image == nep && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(uran, 200, planet1.x, planet1.y - 50);
                        circles.remove(planet2);
                    	circles.set(i, newPlanet);
                        currentScore += 60;
                        play(6);
                    } 
                    if (planet1.size == planet2.size && planet1.image == uran && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(sat, 270, planet1.x, planet1.y - 70);
                        circles.remove(planet2);
                    	circles.set(i, newPlanet);
                        currentScore += 150;
                        play(7);
                    }  
                    if (planet1.size == planet2.size && planet1.image == sat && touching(planet1, planet2)) {              
                    	Planet newPlanet = new Planet(jup, 270, planet1.x, planet1.y);
                        circles.remove(planet2);
                    	circles.set(i, newPlanet);
                        currentScore += 500;
                        g.drawString("YOU WIN! PLAY AGAIN?", 0, 200);
                        play(8);
                    } 
                }
            }
        }
        
        private boolean touching(Planet planet1, Planet planet2) {
            int dx = planet1.x- planet2.x;
            int dy = planet1.y- planet2.y;
            double distance = Math.sqrt(dx*dx + dy*dy);
            return distance < planet1.size/2 + planet2.size/2;
   
        }                   
   
		@Override
		public void mouseClicked(MouseEvent e) {			
            Graphics g = getGraphics();
          
            y = 15;
            
            int ind = rng.nextInt(3);
            selectedImage = planets.get(ind);
            System.out.println(planets.get(ind));
            circles.add(new Planet(selectedImage.image, selectedImage.size, selectedImage.x, selectedImage.y));
            System.out.println(circles);
            
         
            System.out.println("whatt");
            System.out.println(circles.size());
            
            if (circles.size() >= 2) {
            	 beforeLast = circles.get(circles.size() - 2);
            	 System.out.println(circles.get(circles.size()-2));
            	 beforeLast.x = e.getX()-(beforeLast.size/2);
            	 System.out.println(beforeLast.x);
            	 
            	 if (beforeLast.x < 75) {
                 	beforeLast.x = 75;
                 }
                 if (beforeLast.x > 425) {
                 	beforeLast.x = 475 -  (beforeLast.size);
                 }
            	 
            }         
            
            if (timer != null && timer.isRunning()) {
                timer.stop();
            }
            
            timer = new Timer(10, new ActionListener() {     	
                @Override
                public void actionPerformed(ActionEvent e) {
                	
                	
                	if (circles.size() >= 2) {
                		beforeLast.y += 20;
                		checkforCollision();   
                		repaint();
                		
                		if (beforeLast.y + beforeLast.size >= 620) {
                            timer.stop();
                        }
                	}
                	for (int i = 0; i < circles.size() - 3; i++) {
                        Planet planeti = circles.get(i);
                        System.out.println(planeti);
                        if (touching(beforeLast, planeti))  {
                			System.out.println("planets touched");
                			timer.stop();
                    		//checkforCollision();   

                        }  
                }
                	checkforCollision();   
                }
            });
            timer.start();
            
            
            
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}		
    }

    public class Title extends JPanel {
    	
        public Title() {
            setPreferredSize(new Dimension(800, 100));
            setBackground(darkGray);
            
            try {
                airacobra1 = Font.createFont(Font.TRUETYPE_FONT, new File("Airacobra.ttf")).deriveFont(90f);
                GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
                ge.registerFont(airacobra1);
            } catch (IOException | FontFormatException e) {
                e.printStackTrace();
            }
            
            JLabel name = new JLabel("Solar System Saga");
            name.setFont(airacobra1);
            add(name);

        }
    }

    class Planet {
    	
        String name;
        int size;
        Image image;
        int x; 
        int y;
        int xPos;
        int yPos;

        public Planet(String name, int size, Image image) {
        	
            this.name = name;
            this.size = size;
            this.image = image;     
        }
        
        public Planet(Image image, int size, int x, int y) {
        	
            this.size = size;
            this.image = image;
            this.x = x;          
            this.y = y;
            
        }  
        
        public String toString() {
        	return name + " " + size + " " + x + " " + y;
        }
    }
    
    
}
