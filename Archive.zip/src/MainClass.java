import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MainClass extends JPanel implements KeyListener{
	
	boolean restartButton = false;
	Font airacobra1 = null;
	Font airacobra2 = null;
	Font airacobra3 = null;
	
	Image merc = new ImageIcon ("mercury.png").getImage();

	ArrayList <Planet> planets = new ArrayList<Planet>();

	public MainClass(){
		
		Color darkGray = new Color(37, 42, 54);
		Color mutedBlue = new Color(31,62,90);
		Color blueGray = new Color(158, 166, 180);
		Color darkPurple = new Color(86, 61, 130);
		Color rose = new Color(158, 112, 139);
		Color ashGray = new Color(176, 189, 176);
		Color lightGray = new Color(214 ,210 ,196); 
		
		 addKeyListener(this);
		
		try {
			airacobra1 = Font.createFont(Font.TRUETYPE_FONT, new File("Airacobra.ttf")).deriveFont(90f);
			GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
	        ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("Airacobra.ttf")));
	    } catch (IOException|FontFormatException e) {
	         //Handle exception
	    }
		
		try {
			airacobra2 = Font.createFont(Font.TRUETYPE_FONT, new File("Airacobra.ttf")).deriveFont(17f);
			GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
	        ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("Airacobra.ttf")));
	    } catch (IOException|FontFormatException e) {
	         //Handle exception
	    }
		
		try {
			airacobra3 = Font.createFont(Font.TRUETYPE_FONT, new File("Airacobra.ttf")).deriveFont(35f);
			GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
	        ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("Airacobra.ttf")));
	    } catch (IOException|FontFormatException e) {
	         //Handle exception
	    }
		
		
		Planet Mercury = new Planet("Mercury", 10);
		Planet Mars = new Planet("Mars", 15);
		Planet Venus = new Planet("Venus", 20);
		Planet Earth = new Planet("Earth" , 30);
		Planet Neptune = new Planet("Neptune", 40);
		Planet Uranus = new Planet("Uranus", 60);
		Planet Saturn = new Planet("Saturn", 80);
		Planet Jupiter = new Planet("Jupiter", 120);
		planets.add(Mercury);
		planets.add(Mars);
		planets.add(Venus);
		planets.add(Earth);
		planets.add(Neptune);
		planets.add(Uranus);
		planets.add(Saturn);
		planets.add(Jupiter);

		//Collections.shuffle(planets); --> creates randomization
		//

		
		JFrame frame = new JFrame();
	
		JPanel highScore = new JPanel() {
			@Override
			public void paintComponent(Graphics g) {
				super.paintComponent(g);
                g.setColor(Color.black); // Set the color first
                g.drawRect(50, 175, 150, 75);
                g.setColor(blueGray);
                g.fillRect(50, 175, 150, 75);
                g.setColor(Color.black);
                g.setFont(airacobra2);
                g.drawString("CURRENT SCORE", 55, 193);
                g.drawRect(50, 300, 150, 225);
                g.setColor(blueGray);
                g.fillRect(50, 300, 150, 225);
                g.setColor(Color.black); // Set the color first
                g.drawString("TOP SCORE", 55, 318);
                g.drawString("2ND BEST", 55, 393);
                g.drawString("3RD BEST", 55, 468);
                g.drawLine(50, 375, 200, 375);
                g.drawLine(50, 450, 200, 450);
			}
		};

		JPanel gameplay = new JPanel() {
			public void paintComponent(Graphics g) {
				super.paintComponent(g);
				
				if(restartButton) {
                	g.clearRect(0,0,400,550);
                	System.out.println("hello");
                }
				g.drawRect(75,50,400,550);
				g.setColor(darkPurple);
				g.fillRect(75,50,400,550);
				//container for the planets
			}
			
			
			
			public void keyPressed(KeyEvent e) {
				Graphics g = getGraphics(); 
				switch(e.getKeyCode()) {
					case KeyEvent.VK_RIGHT:
						//planet moves right
					case KeyEvent.VK_LEFT:
						//planet moves left
					case KeyEvent.VK_SPACE:
						System.out.println("hello");
						
						//planet drops
				}
			}
			public void keyReleased(KeyEvent e) {
				//one of four small planets randomly appears
			}
			public void keyTyped(KeyEvent e) {
				
			}
		
		};
		
		gameplay.setFocusable(true);		
		
		gameplay.setBackground(darkGray);
		
		
	
		JPanel order = new JPanel();
		JPanel title = new JPanel();
		JButton restart = new JButton("restart");
		JLabel name = new JLabel("Solar System Saga");
		name.setFont(airacobra1);
		restart.setFont(airacobra3);
		
				

		frame.setSize(800, 900);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBackground(darkGray);
        frame.add(title, BorderLayout.NORTH);
		frame.add(highScore, BorderLayout.WEST);
        frame.add(gameplay, BorderLayout.CENTER);
        frame.add(order, BorderLayout.SOUTH);
 
        
        title.add(name);
		title.setPreferredSize(new Dimension (800,100));
		title.setBackground(darkGray);
        
		
        highScore.setBackground(darkGray);
        highScore.add(restart);
        highScore.setPreferredSize(new Dimension(250, 800));
        highScore.setLayout(null);
 
        
        restart.setBounds(50, 50, 150, 75);
        restart.addActionListener(new ActionListener() {			
        	@Override
			public void actionPerformed(ActionEvent e) {
        		restartButton = true;
			}
            
        });

		
        
        
        
        frame.setVisible(true);
	}
	
	class Planet {
		String name;
		int size;
		Image image;
		
		public Planet(String name, int size) {
			this.name = name;
			this.size = size;
			//this.image = image;
		}
		
		public String getName() {
			return name;
		}

		public int getSize() {
			return size;
		}
		
	}

	
	public static void main(String[] args) {
		 new MainClass();
		 
	 }


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		Graphics g = getGraphics(); 
		switch(e.getKeyCode()) {
			case KeyEvent.VK_RIGHT:
				//planet moves right
			case KeyEvent.VK_LEFT:
				//planet moves left
			case KeyEvent.VK_SPACE:
				System.out.println("hello");
				g.drawImage(merc, 23, 23, null);
				//planet drops
		}
	}


	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}


}



